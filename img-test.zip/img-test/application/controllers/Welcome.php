<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller{

public function __construct()
{
    parent:: __construct();

}



public function index(){

    $this->load->Model('pic_model');
    $data['picture_list']=$this->pic_model->get_all_images();

    $this->load->view('header');
    $this->load->view('picture_list',$data);
    $this->load->view('footer');

}

}



?>