<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller{

    public function __construct()
    {
        parent:: __construct();
        $this->load->model('pic_model');
        $this->load->library('form_validation');

    }

    public function form()
    {
        $this->load->view('header');
        $this->load->view('upload_form');
        $this->load->view('footer');
    }


    public function file_data()
    {
        //validate the form
        $this->form_validation->set_rules('pic_title','PIC_TITLE','Required');

        if($this->form_validation->run() === FALSE)
        {
            $this->load->view('upload_form');
        }

        else{
                    //get form value
                    $data['pic_title']=$this->input->post('pic_title',TRUE);
                    $data['pic_desc']=$this->input->post('pic_desc',TRUE);

                    //file upload code
                    //set the file upload setting
                    $config['upload_path']='assets/uploads/';
                    $config['allowed_type']='jpg|png|jpeg|pdf';
                    $config['max_size'] ='100000';

                $this->load->library('upload',$config);

                if( ! $this->upload->do_upload('pic_file'))
                {
                    $error=array('error' =>$this->upload->display_errors());
                    $this->load->view('upload_form',$error);
                }
                else{
                        



                }



        }




    }



}



?>
