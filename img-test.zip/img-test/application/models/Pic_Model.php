<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

class Pic_Model extends CI_Model{
  
  // fetch all the pictures from db
    public function get_all_images()
    {

        $all_pics=$this->db->get("pictures");

        return $all_pics->result();

    }


        //Store the Data into table
    public function store_pic_data( $data)
        {
            
            $insert['pic_title']= $data['pic_title'];
            
            $insert['pic_desc']= $data['pic_desc'];
            
            $insert['pic_file']= $data['pic_file'];
            
            $query=$this->db->insert('pictures',$insert);
        }



}


?>